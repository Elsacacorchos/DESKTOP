﻿Public Class FormEditarUsuarios

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        Dim SqlUpdate As String = "Update UsersClient set LoginName=" & txtusername.Text & ", Password='" & txtpassword.Text & "', FirstName='" & txtname.Text & "', LastName='" & txtlastname.Text & "', Position='" & ComboBoxCount.Text & "', Email='" & txtemail.Text & "'"

        Me.Close()
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Me.Close()
    End Sub


End Class