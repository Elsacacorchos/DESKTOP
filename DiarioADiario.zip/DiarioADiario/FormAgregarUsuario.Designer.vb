﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAgregarUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAgregarUsuario))
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.txtusername1 = New System.Windows.Forms.Label()
        Me.txtpassword1 = New System.Windows.Forms.Label()
        Me.txtname1 = New System.Windows.Forms.Label()
        Me.txtlastname1 = New System.Windows.Forms.Label()
        Me.txtcount1 = New System.Windows.Forms.Label()
        Me.txtemail1 = New System.Windows.Forms.Label()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnEditar = New System.Windows.Forms.Button()
        Me.ComboBoxCount = New System.Windows.Forms.ComboBox()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(175, 136)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(253, 20)
        Me.TextBox7.TabIndex = 1
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(175, 84)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(253, 20)
        Me.TextBox2.TabIndex = 3
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(175, 110)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(253, 20)
        Me.TextBox3.TabIndex = 4
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(175, 159)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(253, 20)
        Me.TextBox4.TabIndex = 5
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(175, 211)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(253, 20)
        Me.TextBox6.TabIndex = 7
        '
        'txtusername1
        '
        Me.txtusername1.AutoSize = True
        Me.txtusername1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtusername1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtusername1.Location = New System.Drawing.Point(60, 87)
        Me.txtusername1.Name = "txtusername1"
        Me.txtusername1.Size = New System.Drawing.Size(109, 13)
        Me.txtusername1.TabIndex = 14
        Me.txtusername1.Text = "Nombre de Usuario"
        '
        'txtpassword1
        '
        Me.txtpassword1.AutoSize = True
        Me.txtpassword1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpassword1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtpassword1.Location = New System.Drawing.Point(103, 113)
        Me.txtpassword1.Name = "txtpassword1"
        Me.txtpassword1.Size = New System.Drawing.Size(66, 13)
        Me.txtpassword1.TabIndex = 15
        Me.txtpassword1.Text = "Contraseña"
        '
        'txtname1
        '
        Me.txtname1.AutoSize = True
        Me.txtname1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtname1.Location = New System.Drawing.Point(119, 139)
        Me.txtname1.Name = "txtname1"
        Me.txtname1.Size = New System.Drawing.Size(50, 13)
        Me.txtname1.TabIndex = 16
        Me.txtname1.Text = "Nombre"
        '
        'txtlastname1
        '
        Me.txtlastname1.AutoSize = True
        Me.txtlastname1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlastname1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtlastname1.Location = New System.Drawing.Point(118, 162)
        Me.txtlastname1.Name = "txtlastname1"
        Me.txtlastname1.Size = New System.Drawing.Size(51, 13)
        Me.txtlastname1.TabIndex = 17
        Me.txtlastname1.Text = "Apellido"
        '
        'txtcount1
        '
        Me.txtcount1.AutoSize = True
        Me.txtcount1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcount1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtcount1.Location = New System.Drawing.Point(125, 188)
        Me.txtcount1.Name = "txtcount1"
        Me.txtcount1.Size = New System.Drawing.Size(44, 13)
        Me.txtcount1.TabIndex = 18
        Me.txtcount1.Text = "Cuenta"
        '
        'txtemail1
        '
        Me.txtemail1.AutoSize = True
        Me.txtemail1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtemail1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtemail1.Location = New System.Drawing.Point(134, 214)
        Me.txtemail1.Name = "txtemail1"
        Me.txtemail1.Size = New System.Drawing.Size(35, 13)
        Me.txtemail1.TabIndex = 19
        Me.txtemail1.Text = "Email"
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(492, 36)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(233, 217)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox1.TabIndex = 30
        Me.pictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(142, Byte), Integer))
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(245, 315)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(149, 40)
        Me.Button1.TabIndex = 32
        Me.Button1.Text = "Guardar"
        Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btnEditar
        '
        Me.btnEditar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditar.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(142, Byte), Integer))
        Me.btnEditar.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnEditar.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnEditar.FlatAppearance.BorderSize = 0
        Me.btnEditar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnEditar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.btnEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEditar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditar.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnEditar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEditar.Location = New System.Drawing.Point(471, 315)
        Me.btnEditar.Name = "btnEditar"
        Me.btnEditar.Size = New System.Drawing.Size(136, 40)
        Me.btnEditar.TabIndex = 33
        Me.btnEditar.Text = "Cancelar"
        Me.btnEditar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnEditar.UseVisualStyleBackColor = False
        '
        'ComboBoxCount
        '
        Me.ComboBoxCount.FormattingEnabled = True
        Me.ComboBoxCount.Items.AddRange(New Object() {"Cuenta Verificada", "Cuenta Normal"})
        Me.ComboBoxCount.Location = New System.Drawing.Point(175, 184)
        Me.ComboBoxCount.Name = "ComboBoxCount"
        Me.ComboBoxCount.Size = New System.Drawing.Size(253, 21)
        Me.ComboBoxCount.TabIndex = 34
        '
        'FormAgregarUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.ComboBoxCount)
        Me.Controls.Add(Me.btnEditar)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.txtemail1)
        Me.Controls.Add(Me.txtcount1)
        Me.Controls.Add(Me.txtlastname1)
        Me.Controls.Add(Me.txtname1)
        Me.Controls.Add(Me.txtpassword1)
        Me.Controls.Add(Me.txtusername1)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox7)
        Me.Name = "FormAgregarUsuario"
        Me.Text = "FormAgregarUsuario"
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents txtusername1 As Label
    Friend WithEvents txtpassword1 As Label
    Friend WithEvents txtname1 As Label
    Friend WithEvents txtlastname1 As Label
    Friend WithEvents txtcount1 As Label
    Friend WithEvents txtemail1 As Label
    Private WithEvents pictureBox1 As PictureBox
    Private WithEvents Button1 As Button
    Private WithEvents btnEditar As Button
    Friend WithEvents ComboBoxCount As ComboBox
End Class
