﻿Public Class FormConfiguraciones
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If TextBox1.Text = Nothing Or TextBox2.Text = Nothing Then

            lblinfo.text = "Introduce datos"
            lblinfo.Visible = True
            CheckBox1.CheckState = My.Settings.recordar


            If CheckBox1.Checked = True Then
                My.Settings.User = TextBox1.Text
                My.Settings.Pass = TextBox2.Text
                My.Settings.recordar = 1
                My.Settings.Save()
            Else
                My.Settings.User = ""
                My.Settings.Pass = ""
                My.Settings.recordar = 0
                My.Settings.Save()
                TextBox1.Text = ""
                TextBox2.Text = ""

            End If

        End If
    End Sub

    Private Sub FormConfiguraciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = My.Settings.User
        TextBox2.Text = My.Settings.Pass
        CheckBox1.CheckState = My.Settings.recordar


        If My.Settings.Maximizar = 1 Then
            Maximizar.Checked = True
        Else
            Maximizar.Checked = False
        End If

        Minimizar.CheckState = My.Settings.Minimizar

        Ventana.CheckState = My.Settings.Ventana

        If My.Settings.ColorFondo = Color.White Then
            RadioButton1.Checked = True
        Else
            RadioButton1.Checked = False
        End If

        If My.Settings.ColorFondo = Color.DarkGray Then
            RadioButton2.Checked = True
        Else
            RadioButton2.Checked = False
        End If

        If My.Settings.ColorFondo = Color.Blue Then
            RadioButton3.Checked = True
        Else
            RadioButton3.Checked = False
        End If

        If My.Settings.ColorFondo = Color.Pink Then
            RadioButton4.Checked = True
        Else
            RadioButton4.Checked = False
        End If
    End Sub

    Private Sub Maximizar_CheckedChanged(sender As Object, e As EventArgs) Handles Maximizar.CheckedChanged
        If Maximizar.Checked = True Then
            My.Settings.Max = 1
            My.Settings.Save()
        Else
            My.Settings.Max = 0
            My.Settings.Save()

        End If
    End Sub

    Private Sub Ventana_CheckedChanged(sender As Object, e As EventArgs) Handles Ventana.CheckedChanged
        If Ventana.Checked = True Then
            My.Settings.Top = 1
            My.Settings.Save()
        Else
            My.Settings.Top = 0
            My.Settings.Save()

        End If
    End Sub



    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        My.Settings.ColorFondo = Color.DarkGray
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        My.Settings.ColorFondo = Color.Blue
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        My.Settings.ColorFondo = Color.Pink
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        My.Settings.ColorFondo = Color.White
    End Sub
End Class