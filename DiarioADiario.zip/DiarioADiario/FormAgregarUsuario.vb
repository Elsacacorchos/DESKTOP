﻿Public Class FormAgregarUsuario
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Sql As String = "Insert Into UsersClient (LoginName, Password, FirstName, LastName, Position, Email) Select " & TextBox2.Text & ", '" & TextBox3.Text & "', '" & TextBox7.Text & "', '" & TextBox4.Text & "', '" & ComboBoxCount.Text & "', '" & TextBox6.Text & "'"

        Me.Close()
    End Sub
End Class