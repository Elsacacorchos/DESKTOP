﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormEditarUsuarios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormEditarUsuarios))
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.txtusername = New System.Windows.Forms.TextBox()
        Me.txtpassword = New System.Windows.Forms.TextBox()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.txtlastname = New System.Windows.Forms.TextBox()
        Me.txtemail = New System.Windows.Forms.TextBox()
        Me.txtusername1 = New System.Windows.Forms.Label()
        Me.txtid1 = New System.Windows.Forms.Label()
        Me.txtpassword1 = New System.Windows.Forms.Label()
        Me.txtname1 = New System.Windows.Forms.Label()
        Me.txtlastname1 = New System.Windows.Forms.Label()
        Me.txtcount1 = New System.Windows.Forms.Label()
        Me.txtemail1 = New System.Windows.Forms.Label()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnGuardar = New System.Windows.Forms.Button()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.ComboBoxCount = New System.Windows.Forms.ComboBox()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(139, 43)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(253, 20)
        Me.txtid.TabIndex = 0
        '
        'txtusername
        '
        Me.txtusername.Location = New System.Drawing.Point(139, 69)
        Me.txtusername.Name = "txtusername"
        Me.txtusername.Size = New System.Drawing.Size(253, 20)
        Me.txtusername.TabIndex = 1
        '
        'txtpassword
        '
        Me.txtpassword.Location = New System.Drawing.Point(139, 95)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(253, 20)
        Me.txtpassword.TabIndex = 2
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(139, 121)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(253, 20)
        Me.txtname.TabIndex = 3
        '
        'txtlastname
        '
        Me.txtlastname.Location = New System.Drawing.Point(139, 147)
        Me.txtlastname.Name = "txtlastname"
        Me.txtlastname.Size = New System.Drawing.Size(253, 20)
        Me.txtlastname.TabIndex = 4
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(139, 199)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(253, 20)
        Me.txtemail.TabIndex = 6
        '
        'txtusername1
        '
        Me.txtusername1.AutoSize = True
        Me.txtusername1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtusername1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtusername1.Location = New System.Drawing.Point(24, 72)
        Me.txtusername1.Name = "txtusername1"
        Me.txtusername1.Size = New System.Drawing.Size(109, 13)
        Me.txtusername1.TabIndex = 11
        Me.txtusername1.Text = "Nombre de Usuario"
        '
        'txtid1
        '
        Me.txtid1.AutoSize = True
        Me.txtid1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtid1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtid1.Location = New System.Drawing.Point(114, 46)
        Me.txtid1.Name = "txtid1"
        Me.txtid1.Size = New System.Drawing.Size(18, 13)
        Me.txtid1.TabIndex = 12
        Me.txtid1.Text = "ID"
        '
        'txtpassword1
        '
        Me.txtpassword1.AutoSize = True
        Me.txtpassword1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpassword1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtpassword1.Location = New System.Drawing.Point(66, 98)
        Me.txtpassword1.Name = "txtpassword1"
        Me.txtpassword1.Size = New System.Drawing.Size(66, 13)
        Me.txtpassword1.TabIndex = 13
        Me.txtpassword1.Text = "Contraseña"
        '
        'txtname1
        '
        Me.txtname1.AutoSize = True
        Me.txtname1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtname1.Location = New System.Drawing.Point(82, 124)
        Me.txtname1.Name = "txtname1"
        Me.txtname1.Size = New System.Drawing.Size(50, 13)
        Me.txtname1.TabIndex = 14
        Me.txtname1.Text = "Nombre"
        '
        'txtlastname1
        '
        Me.txtlastname1.AutoSize = True
        Me.txtlastname1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlastname1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtlastname1.Location = New System.Drawing.Point(82, 150)
        Me.txtlastname1.Name = "txtlastname1"
        Me.txtlastname1.Size = New System.Drawing.Size(51, 13)
        Me.txtlastname1.TabIndex = 15
        Me.txtlastname1.Text = "Apellido"
        '
        'txtcount1
        '
        Me.txtcount1.AutoSize = True
        Me.txtcount1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcount1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtcount1.Location = New System.Drawing.Point(89, 176)
        Me.txtcount1.Name = "txtcount1"
        Me.txtcount1.Size = New System.Drawing.Size(44, 13)
        Me.txtcount1.TabIndex = 16
        Me.txtcount1.Text = "Cuenta"
        '
        'txtemail1
        '
        Me.txtemail1.AutoSize = True
        Me.txtemail1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtemail1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtemail1.Location = New System.Drawing.Point(98, 202)
        Me.txtemail1.Name = "txtemail1"
        Me.txtemail1.Size = New System.Drawing.Size(35, 13)
        Me.txtemail1.TabIndex = 17
        Me.txtemail1.Text = "Email"
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(508, 21)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(233, 217)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pictureBox1.TabIndex = 29
        Me.pictureBox1.TabStop = False
        '
        'btnGuardar
        '
        Me.btnGuardar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnGuardar.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(142, Byte), Integer))
        Me.btnGuardar.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnGuardar.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnGuardar.FlatAppearance.BorderSize = 0
        Me.btnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnGuardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGuardar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGuardar.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGuardar.Location = New System.Drawing.Point(230, 292)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(149, 40)
        Me.btnGuardar.TabIndex = 31
        Me.btnGuardar.Text = "Guardar"
        Me.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnGuardar.UseVisualStyleBackColor = False
        '
        'btnCancelar
        '
        Me.btnCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(13, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(142, Byte), Integer))
        Me.btnCancelar.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.DimGray
        Me.btnCancelar.FlatAppearance.BorderSize = 0
        Me.btnCancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnCancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelar.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancelar.Location = New System.Drawing.Point(458, 292)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(136, 40)
        Me.btnCancelar.TabIndex = 32
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnCancelar.UseVisualStyleBackColor = False
        '
        'ComboBoxCount
        '
        Me.ComboBoxCount.FormattingEnabled = True
        Me.ComboBoxCount.Items.AddRange(New Object() {"Cuenta Verificada", "Cuenta Normal"})
        Me.ComboBoxCount.Location = New System.Drawing.Point(139, 172)
        Me.ComboBoxCount.Name = "ComboBoxCount"
        Me.ComboBoxCount.Size = New System.Drawing.Size(253, 21)
        Me.ComboBoxCount.TabIndex = 33
        '
        'FormEditarUsuarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.ComboBoxCount)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnGuardar)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.txtemail1)
        Me.Controls.Add(Me.txtcount1)
        Me.Controls.Add(Me.txtlastname1)
        Me.Controls.Add(Me.txtname1)
        Me.Controls.Add(Me.txtpassword1)
        Me.Controls.Add(Me.txtid1)
        Me.Controls.Add(Me.txtusername1)
        Me.Controls.Add(Me.txtemail)
        Me.Controls.Add(Me.txtlastname)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.txtpassword)
        Me.Controls.Add(Me.txtusername)
        Me.Controls.Add(Me.txtid)
        Me.Name = "FormEditarUsuarios"
        Me.Text = "FormEditarUsuarios"
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtid As TextBox
    Friend WithEvents txtusername As TextBox
    Friend WithEvents txtpassword As TextBox
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtlastname As TextBox
    Friend WithEvents txtemail As TextBox
    Friend WithEvents txtusername1 As Label
    Friend WithEvents txtid1 As Label
    Friend WithEvents txtpassword1 As Label
    Friend WithEvents txtname1 As Label
    Friend WithEvents txtlastname1 As Label
    Friend WithEvents txtcount1 As Label
    Friend WithEvents txtemail1 As Label
    Private WithEvents pictureBox1 As PictureBox
    Private WithEvents btnGuardar As Button
    Private WithEvents btnCancelar As Button
    Friend WithEvents ComboBoxCount As ComboBox
End Class
