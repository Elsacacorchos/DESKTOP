﻿Public Class FormUsers

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        Me.Close()
    End Sub

    Private Sub FormUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.UsersClientTableAdapter.Fill(Me.DDBDDataSet.UsersClient)

    End Sub

    Private Sub BtnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        If (DataGridView1.SelectedRows.Count > 0) Then
            Dim frm As New FormEditarUsuarios
            frm.txtid.Text = DataGridView1.CurrentRow.Cells(0).Value.ToString()
            frm.txtusername.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString()
            frm.txtpassword.Text = DataGridView1.CurrentRow.Cells(2).Value.ToString()
            frm.txtname.Text = DataGridView1.CurrentRow.Cells(3).Value.ToString()
            frm.txtlastname.Text = DataGridView1.CurrentRow.Cells(4).Value.ToString()
            frm.ComboBoxCount.Text = DataGridView1.CurrentRow.Cells(5).Value.ToString()
            frm.txtemail.Text = DataGridView1.CurrentRow.Cells(6).Value.ToString()


            frm.ShowDialog()
        Else
            MessageBox.Show("Por favor seleccione una fila...")
        End If

    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        FormAgregarUsuario.Show()
    End Sub
End Class