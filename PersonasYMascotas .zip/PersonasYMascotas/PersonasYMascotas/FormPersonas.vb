﻿Public Class FormPersonas
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles labelPersonas.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles textCi.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub btnCapturarPersonas_Click(sender As Object, e As EventArgs) Handles btnCapturarPersonas.Click
        Try

            Dim cedula As New Integer
            cedula = textCi.Text


            Dim ci As Integer
            Dim nombre As String
            Dim telefono As Integer
            Dim direccion As String

            Dim personaUser As New Persona
            personaUser.CI = textCi.Text
            personaUser.Nombre = textNombre.Text
            personaUser.Telefono = textTelefono.Text
            personaUser.Direccion = textDireccion.Text



            Dim logica As New LogicaPersona
            logica.altaPersona(personaUser)
        Catch
            MsgBox("Hubo un error")
        End Try
    End Sub

    Private Sub labelVerResultado_Click(sender As Object, e As EventArgs) Handles labelVerResultado.Click


    End Sub
End Class
