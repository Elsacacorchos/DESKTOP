﻿Public Class PersistenciaPerson
    Sub New()
    End Sub

    Dim conetionPP = New Npgsql.NpgsqlConnection
    Public Sub altaPersona(personaUser As Persona)
        Try
            Dim classcnn = New Conexion
            conetionPP = classcnn.AbrirConexion
            Dim cadenaDeComandos As String
            cadenaDeComandos = "insert into persona(ci, nombre, direccion) values (@ci, @nombre, @direccion)"
            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.Connection = conetionPP
            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.CI
            cmd.Parameters.Add("@nombre", NpgsqlTypes.NpgsqlDbType.Varchar, 50).Value = personaUser.Nombre
            cmd.Parameters.Add("@direccion", NpgsqlTypes.NpgsqlDbType.Varchar, 80).Value = personaUser.Direccion

            Dim resultado As Integer
            resultado = cmd.ExecuteNonQuery()


        Catch ex As Exception
            Throw ex
        Finally
            conetionPP.close

        End Try
    End Sub

End Class
