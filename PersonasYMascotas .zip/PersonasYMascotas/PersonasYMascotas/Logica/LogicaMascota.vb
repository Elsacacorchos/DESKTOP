﻿Public Class LogicaMascota

End Class
