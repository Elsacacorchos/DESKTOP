﻿

Public Class LogicaPersona
    Public Sub altaPersona(personaUser As Persona)

        Dim persistencia As New PersistenciaPerson
        persistencia.altaPersona(personaUser)


    End Sub
End Class
