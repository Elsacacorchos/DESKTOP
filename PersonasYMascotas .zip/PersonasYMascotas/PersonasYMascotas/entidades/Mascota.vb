﻿Public Class Mascota
    Private _id As Integer
    Private _dueno As Persona
    Private _nombre As String
    Private _añonacimiento As Integer




    Public Property Dueno As Persona
        Get
            Return _dueno
        End Get
        Set(value As Persona)
            _dueno = value
        End Set
    End Property

    Public Property Nombre As String
        Get
            Return _nombre
        End Get
        Set(value As String)
            _nombre = value
        End Set
    End Property
    Public Property Añonacimiento As Integer
        Get
            Return _añonacimiento
        End Get
        Set(value As Integer)
            _añonacimiento = value
        End Set
    End Property

    Public Property id As Integer
        Get
            Return _id
        End Get
        Set(value As Integer)
            _id = value
        End Set
    End Property
    Public Sub Mascotas()

    End Sub

    Public Sub Mascotas(nombre_ As String, dueno_ As Persona, añonacimiento_ As Integer, id_ As Integer)
        Nombre = nombre_
        Dueno = dueno_
        Añonacimiento = añonacimiento_
        id = id_
    End Sub

End Class

