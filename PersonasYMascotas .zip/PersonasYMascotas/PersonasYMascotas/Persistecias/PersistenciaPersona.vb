﻿Imports Npgsql

Public Class PersistenciaPerson
    Sub New()
    End Sub

    Dim conetionPP = New Npgsql.NpgsqlConnection
    Public Sub altaPersona(personaUser As Persona)
        Try
            Dim classcnn = New Conexion
            conetionPP = classcnn.AbrirConexion

            Dim cmd As New Npgsql.NpgsqlCommand
            cmd.Connection = conetionPP

            Dim cadenaDeComandos As String
            cadenaDeComandos = "insert into persona(ci, nombre, direccion) values (@ci, @nombre, @direccion)"
            cmd.CommandText = cadenaDeComandos

            cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.CI
            cmd.Parameters.Add("@nombre", NpgsqlTypes.NpgsqlDbType.Varchar, 50).Value = personaUser.Nombre
            cmd.Parameters.Add("@direccion", NpgsqlTypes.NpgsqlDbType.Varchar, 80).Value = personaUser.Direccion

            Dim resultado As Integer
            resultado = cmd.ExecuteNonQuery()

            If resultado = 1 Then
                Dim i As Integer
                i = 0

                While i < personaUser.Telefono.Count
                    cadenaDeComandos = "INSERT INTO telefonos (ci, telefonos) VALUES(@ci, @telefono);"
                    cmd.CommandText = cadenaDeComandos

                    cmd.Parameters.Add("@ci", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.CI
                    cmd.Parameters.Add("@telefono", NpgsqlTypes.NpgsqlDbType.Integer).Value = personaUser.Telefono.Item(i)


                    resultado = cmd.ExecuteNonQuery()

                    i = i + 1
                End While

            End If
        Catch ex As Exception
            Throw ex
        Finally
            conetionPP.close

        End Try
    End Sub

End Class
