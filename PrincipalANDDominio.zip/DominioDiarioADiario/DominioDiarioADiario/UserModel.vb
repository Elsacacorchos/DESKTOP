﻿Imports DatosDiarioADiario
Imports CommonDiarioADiario

Public Class UserModel

    Dim userDao As New UserDao()


    Private idUser
    Private loginName
    Private password
    Private firstName
    Private lastName
    Private position
    Private email


    Public Sub New(idUser As Object, loginName As Object, password As Object, firstName As Object, lastName As Object, position As Object, email As Object)
        Me.idUser = idUser
        Me.loginName = loginName
        Me.password = password
        Me.firstName = firstName
        Me.lastName = lastName
        Me.position = position
        Me.email = email
    End Sub

    Public Sub New()

    End Sub


    Public Function editUserProfile() As String
        Try
            userDao.editProfile(idUser, loginName, password, firstName, lastName, email)
            Login(loginName, password)
            Return "Tu perfil fue exitosamente actualizado"
        Catch ex As Exception
            Return "Ese nombre de Usuario ya esta registrado "
        End Try
    End Function

    Public Function Login(user As String, pass As String) As Boolean
        Return userDao.Login(user, pass)
    End Function

End Class
