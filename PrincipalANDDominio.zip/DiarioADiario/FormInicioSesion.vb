﻿Imports System.Runtime.InteropServices
Imports DominioDiarioADiario
Imports CommonDiarioADiario

Public Class FormInicioSesion
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim userModel As New UserModel()
        Dim validLogin = userModel.Login(txtUser.Text, txtPass.Text)
        If validLogin = True Then
            Dim frm As New Form()
            frm.Show()
            AddHandler frm.FormClosed, AddressOf Me.Logout
            Me.Hide()
        Else
            MessageBox.Show("Incorrect username or password entered." + vbNewLine + "Please try again.")
            txtPass.Clear()
            txtPass.Focus()
        End If
    End Sub
    Private Sub Logout(sender As Object, e As FormClosedEventArgs)
        txtUser.Clear()
        txtPass.Clear()
        Me.Show()
        txtUser.Focus()
    End Sub
    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CustomizeComponents()
    End Sub

    Private Sub CustomizeComponents()
        Throw New NotImplementedException()
    End Sub
    'Customize Controls - Personalizar Controles"
    'Close and Minimize Form - Cerrar y Minimizar Formulario"
    'Drag Form - Arrastrar/ mover Formulario"
End Class

