﻿Imports System.Data.SqlClient
Imports CommonDiarioADiario


Public Class UserDao
    Inherits ConnectionToSql
    Public Function Login(user As String, pass As String) As Boolean
        Using connection = GetConnection()
            connection.Open()
            Using command = New SqlCommand()
                command.Connection = connection
                command.CommandText = "select * from usersadmin where loginName=@user and password=@pass"
                command.Parameters.AddWithValue("@user", user)
                command.Parameters.AddWithValue("@pass", pass)
                command.CommandType = CommandType.Text
                Dim reader = command.ExecuteReader()
                If reader.HasRows Then
                    While reader.Read() 'Obtenemos los datos de la columna y asignamos a los campos de usuario activo en cache'
                        ActiveUser.idUser = reader.GetInt32(0)
                        ActiveUser.loginName = reader.GetString(1)
                        ActiveUser.password = reader.GetString(2)
                        ActiveUser.firstName = reader.GetString(3)
                        ActiveUser.lastName = reader.GetString(4)
                        ActiveUser.position = reader.GetString(5)
                        ActiveUser.email = reader.GetString(6)
                    End While
                    reader.Dispose()
                    Return True
                Else
                    Return False
                End If
            End Using
        End Using
    End Function

    Public Sub editProfile(id, user, pass, name, lastName, mail)
        Using connection = GetConnection()
            connection.Open()
            Using command = New SqlCommand()
                command.Connection = connection
                command.CommandText = "update Users set LoginName=@user, Password=@pass, FirstName=@name, LastName=@lastName, Email=@mail where UserID=@id"
                command.Parameters.AddWithValue("@user", user)
                command.Parameters.AddWithValue("@pass", pass)
                command.Parameters.AddWithValue("@name", name)
                command.Parameters.AddWithValue("@lastName", lastName)
                command.Parameters.AddWithValue("@mail", mail)
                command.Parameters.AddWithValue("@id", id)
                command.CommandType = CommandType.Text
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub
End Class