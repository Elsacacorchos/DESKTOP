﻿Imports System.Data.SqlClient



Public MustInherit Class ConnectionToSql
    Public connectionString
    Protected Sub New()
        connectionString = "Data Source=DESKTOP-GL2VC9T\SQLSERVER;Initial Catalog=DDBD;Persist Security Info=True;User ID=sa;Password=pmendez"

    End Sub
    Protected Function GetConnection() As SqlConnection
        Return New SqlConnection(connectionString)
    End Function

    Sub conexion()
        ':::Instruccion Try para capturar errores
        Try
            ':::Abrimos nuestro conexion con la propiedad Open
            connectionString.Open()
            MsgBox("Conexión realizada de manera exitosa", MsgBoxStyle.Information, "Tutorial CRUD")
            ':::Y cerramos la conexion
            connectionString.Close()
        Catch ex As Exception
            MsgBox("No se logro realizar la conexión debido: " & ex.Message, MsgBoxStyle.Critical, "Tutorial CRUD")
        End Try
    End Sub


End Class

