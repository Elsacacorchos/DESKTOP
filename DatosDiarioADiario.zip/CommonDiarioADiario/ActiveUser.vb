﻿Public Module ActiveUser

    Public idUser
    Public loginName
    Public password
    Public firstName
    Public lastName
    Public position
    Public email

End Module
