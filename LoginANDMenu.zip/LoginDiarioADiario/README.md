# Login-Plano-Moderno-Transparente-WinForm-VB
Diseñar Formulario Login Plano Moderno Transparente y Botón Circular- Visual Basic y WinForm
<h2>Tutorial:</h2>
<h3>Blog:</h3>
https://rjcodeadvance.com/cap-1-login-disenar-formulario-login-moderno-boton-circular-transparencia-vb-y-winform/
<h3>YouTube:</h3>
https://www.youtube.com/watch?v=MiA7vKqtF5Q
</br></br>
<img src="https://rjcodeadvance.com/wp-content/uploads/2019/08/Login-Disign-VB.png">
